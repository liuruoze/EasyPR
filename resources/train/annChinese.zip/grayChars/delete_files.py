import os

if __name__ == "__main__":
        for root, dirs, files in os.walk("./"):
                for name in files:
                        if name.find("py") == -1:
                                filepath = root + name
                                print filepath
                for name in dirs:
                        print name
                        for r, dirs, files in os.walk(name):
                                for f in files: 
                                        filepath = r + '/' + f
                                        print filepath
                                        os.remove(filepath)
                
